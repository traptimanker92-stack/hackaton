# AccessEase – Your World, Without Barriers

A static, no-build accessibility web app. Open it through a local server (camera, microphone and the service worker need `localhost` or HTTPS):

    cd accessease
    python3 -m http.server 8000     # then open http://localhost:8000

Deploy by uploading the folder to any static host (Netlify, Vercel, GitHub Pages, etc.). Chrome or Edge recommended.

## What works
| Area | Status |
|---|---|
| Display settings: light/dark/high contrast, text size, reduce motion, easy-read font, saved on device | Working |
| Voice assistant (floating button; push-to-talk or typed; English/Hinglish keyword commands) | Working in Chrome/Edge; typed input everywhere |
| Vision & OCR: camera or upload, Tesseract.js text extraction, read aloud | Working (needs internet for the library and language data) |
| Speech & Captions: text to speech, speech to text, save transcript, global live captions bar | Working (speech input needs Chrome/Edge) |
| Reader & Learning: .txt and text-based .pdf (pdf.js), basic summary, simplify, step view, dates/amounts, read aloud | Working, rule-based and rough |
| Communication board (tap tiles, custom phrases, speak) | Working, no drag-and-drop needed |
| Daily life: tasks, reminders (only while page is open), notes | Working |
| Emergency: `tel:112` and `sms:` links with location, each behind a confirmation | Working; the app never places calls or claims an alert was sent |
| Reading guide bar and line-spacing control | Working |
| Loud-sound alert (banner + vibration; loudness only, not sound recognition) | Working |
| Step-by-step guided routines, read aloud one step at a time | Working |
| Medical ID (stored on device, shown large or read aloud) | Working |
| Voice commands for scrolling, back, read page; keyboard shortcuts (Alt+1–8, Alt+V, Alt+C) | Working |
| Backup/restore of all saved data; install button | Working |
| PWA manifest + service worker | Present; online-first with cache fallback |

## Not included in this build
- AI layer (Gemini or other LLM): image descriptions, photo Q&A, smart intent routing, translation, smart simplification. These need a server that keeps the API key private.
- Wake phrase ("Hey AccessEase"): not possible reliably in browsers. Push-to-talk is used.
- Sound *recognition* (doorbell vs alarm), sign-language detection, login/database.
- Translated interface: UI text is English; the language menu controls speech, recognition and OCR.

## Language Support Matrix
Speech output depends on voices installed on the user's device. The **Languages & support** page checks this live. Speech input depends on the browser's recognizer; Chrome and Edge support most listed languages, others may fail. OCR downloads per-language data on first use.

| Language | Speech output | Speech input | OCR |
|---|---|---|---|
| English, Hindi, Bengali, Marathi, Tamil, Telugu, Gujarati, Kannada, Malayalam, Punjabi, Urdu, Odia, Assamese | Device-dependent | Browser-dependent (Assamese and Odia are least likely) | Tesseract language data |
| Spanish, French, Arabic, Chinese | Device-dependent | Browser-dependent | Tesseract language data |

## Accessibility status
Built toward WCAG 2.2 AA: skip link, semantic landmarks, visible focus, 44px targets, no dragging, keyboard-operable controls, dialogs for confirmations. **It has not been audited with axe-core or tested with NVDA, TalkBack or VoiceOver.** Do that before relying on it.
